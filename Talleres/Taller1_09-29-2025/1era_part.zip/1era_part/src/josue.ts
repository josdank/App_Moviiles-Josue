let fecha_muerte_dinos:number= 453453634;
let dinosauriofavorito:string= 'carnotauro';
let extinto:boolean= true;
let variable1

//Tuplas
let animales:string[] = ["perro","gato","oveja"];
let nues:number[] = [1, 2, 3];

// Leer Tuplas
let tupla:[number, string[]]= [1, ["Hola","Mundo"]]

// sin enum
const tallaChica = "s";
const mediana = "m";
const grande= "g";

enum Talla{
    tallaChica = "s",
    mediana = "m",
    grande = "g",
}

// en JavaScript Los objetos son dinamicos
/*const objetos = {
    id:1
}

objetos.nombre = "Josué Guerra"*/

// Typescript
const objeto : { /*definir las variables de un objeto que es*/
    id:number,
    nombre:string,
} = {id:1, nombre:''}
