export type Progreso = {
  id: string;
  plan_id: string;
  fecha: string;
  notas?: string;
  valor?: number;
  media_url?: string;
  created_at: string;
};
