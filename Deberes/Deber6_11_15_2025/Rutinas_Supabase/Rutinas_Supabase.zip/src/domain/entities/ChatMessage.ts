export type ChatMessage = {
  id: number;
  plan_id: string;
  sender_id: string;
  content: string;
  created_at: string;
};
