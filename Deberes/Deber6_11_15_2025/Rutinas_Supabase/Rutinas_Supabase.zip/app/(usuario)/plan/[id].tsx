import { useEffect, useState } from 'react';
import { View, TextInput, Button, FlatList, Text } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { listarMensajes, enviarMensaje, suscribirChat } from '../../../src/data/repositories/ChatRepo';
import { registrarProgreso, listarProgreso } from '../../../src/data/repositories/ProgresoRepo';
import { MessageBubble } from '../../../src/presentation/components/MessageBubble';
import { supabase } from '../../../src/shared/infra/supabase/client';
import { theme } from '../../../src/shared/styles/theme';

export default function PlanDetailScreen() {
  const { id: planId } = useLocalSearchParams<{ id: string }>();
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [userId, setUserId] = useState('');
  const [progreso, setProgreso] = useState<any[]>([]);
  const [nota, setNota] = useState('');

  useEffect(() => {
    let subscription: any;
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUserId(user?.id ?? '');
      setMessages(await listarMensajes(planId));
      setProgreso(await listarProgreso(planId));
      subscription = suscribirChat(planId, (msg) => setMessages((prev) => [...prev, msg]));
    })();
    return () => { subscription?.unsubscribe?.(); };
  }, [planId]);

  const onSend = async () => {
    if (!text.trim()) return;
    await enviarMensaje(planId, text.trim());
    setText('');
  };

  const onAddProgreso = async () => {
    await registrarProgreso(planId, nota);
    setProgreso(await listarProgreso(planId));
    setNota('');
  };

  return (
    <View style={{ flex:1, padding: theme.spacing(2) }}>
      <Text style={{ color: theme.colors.text, fontWeight:'700', fontSize: 18 }}>Chat</Text>
      <FlatList
        data={messages}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <MessageBubble content={item.content} sender={item.sender_id} mine={item.sender_id === userId} />
        )}
      />
      <View style={{ flexDirection:'row', marginTop: theme.spacing(1) }}>
        <TextInput
          style={{
            flex:1,
            borderWidth:1, borderColor: theme.colors.border,
            backgroundColor: theme.colors.card, color: theme.colors.text,
            padding: theme.spacing(2), borderRadius: theme.radius
          }}
          value={text}
          onChangeText={setText}
          placeholder="Escribe un mensaje"
          placeholderTextColor={theme.colors.subtext}
        />
        <Button title="Enviar" onPress={onSend} />
      </View>

      <Text style={{ color: theme.colors.text, fontWeight:'700', fontSize: 18, marginTop: theme.spacing(2) }}>Progreso</Text>
      <FlatList
        data={progreso}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ padding: theme.spacing(1) }}>
            <Text style={{ color: theme.colors.subtext }}>{item.fecha} — {item.notas}</Text>
          </View>
        )}
      />
      <TextInput
        style={{
          borderWidth:1, borderColor: theme.colors.border,
          backgroundColor: theme.colors.card, color: theme.colors.text,
          padding: theme.spacing(2), borderRadius: theme.radius, marginTop: theme.spacing(1)
        }}
        value={nota}
        onChangeText={setNota}
        placeholder="Añade una nota de progreso"
        placeholderTextColor={theme.colors.subtext}
      />
      <Button title="Registrar progreso" onPress={onAddProgreso} />
    </View>
  );
}
