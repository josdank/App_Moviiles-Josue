import { useState, useEffect } from 'react';
import { View, Text, TextInput, Button as RNButton, FlatList, Alert } from 'react-native';
import {  listMyRutinas } from '../../src/data/repositories/RutinaRepo';
import { asignarPlan } from '../../src/data/repositories/PlanRepo';
import { Card } from '../../src/presentation/components/Card';
import { theme } from '../../src/shared/styles/theme';

export default function AsignarPlanScreen() {
  const [rutinas, setRutinas] = useState<any[]>([]);
  const [usuarioId, setUsuarioId] = useState('');
  const [rutinaId, setRutinaId] = useState('');
  const [objetivo, setObjetivo] = useState('');

  useEffect(() => { (async () => setRutinas(await  listMyRutinas()))(); }, []);

  const onAsignar = async () => {
    try {
      if (!usuarioId || !rutinaId) return Alert.alert('Atención', 'Selecciona rutina y usuario');
      await asignarPlan(rutinaId, usuarioId, new Date().toISOString().slice(0,10), objetivo);
      Alert.alert('Éxito', 'Plan asignado al usuario');
      setObjetivo('');
    } catch (e: any) {
      Alert.alert('Error', e.message);
    }
  };

  return (
    <View style={{ flex:1, padding: theme.spacing(2) }}>
      <Text style={{ color: theme.colors.text, fontWeight:'700', fontSize: 20 }}>Asignar rutina a usuario</Text>
      <Card>
        <TextInput
          placeholder="ID del usuario (profiles.id)"
          placeholderTextColor={theme.colors.subtext}
          value={usuarioId}
          onChangeText={setUsuarioId}
          style={{ borderWidth:1, borderColor: theme.colors.border, backgroundColor: theme.colors.card, color: theme.colors.text, padding: theme.spacing(2), borderRadius: theme.radius }}
        />
        <FlatList
          data={rutinas}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <RNButton title={`Seleccionar: ${item.titulo}`} onPress={() => setRutinaId(item.id)} />
          )}
        />
        <TextInput
          placeholder="Objetivo"
          placeholderTextColor={theme.colors.subtext}
          value={objetivo}
          onChangeText={setObjetivo}
          style={{ borderWidth:1, borderColor: theme.colors.border, backgroundColor: theme.colors.card, color: theme.colors.text, padding: theme.spacing(2), borderRadius: theme.radius, marginTop: theme.spacing(1) }}
        />
        <RNButton title="Asignar" onPress={onAsignar} />
      </Card>
    </View>
  );
}
