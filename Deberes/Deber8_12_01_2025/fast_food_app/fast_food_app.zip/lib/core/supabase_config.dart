import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseConfig {
  static const supabaseUrl = 'TU_SUPABASE_URL';
  static const anonKey = 'TU_SUPABASE_ANON_KEY';

  static Future<void> init() async {
    await Supabase.initialize(
      url: supabaseUrl,
      anonKey: anonKey,
    );
  }
}
